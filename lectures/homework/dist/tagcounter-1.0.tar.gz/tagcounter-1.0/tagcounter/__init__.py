def init():
    print("You have imported homework package")